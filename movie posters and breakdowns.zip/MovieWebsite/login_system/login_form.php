<?php

session_start();

@include 'config.php';

$error = []; // Initialize the $error array

if(isset($_POST['login'])){
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $password = $_POST['password'];

   $select = "SELECT * FROM tbl_registration WHERE email = '$email'";
   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){
      $row = mysqli_fetch_assoc($result);
      $stored_password = $row['password'];

      if($password == $stored_password ){
         header('location: ../seat.php'); // Replace 'dashboard.php' with the actual destination after successful login
      } else {
         $error[] = 'Incorrect password';
      }
   } else {
      $error[] = 'User not found';
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login Form</title>
   <link rel="stylesheet" href="../index.css">
   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav id="navbar">
        <ul>
            <div id="home_logo">
                <a href="index.html"><img src="home_logo.png" alt=""></a>
            </div>
            <li class="item"><a href="../movies(mysuru).html">Movies</a></li>
            <li class="item"><a href="/events">Events</a></li>
            <li class="item"><a href="/plays">Plays</a></li>
            <li class="item"><a href="/sports">Sports</a></li>
            <li class="item"><a href="/contact">Contact</a></li>
            <li class="item" id="joinus"><a href="/joinus">Join Us</a></li>
        </ul>
</nav>   
<div class="form-container">
   <form action="" method="post">
      <h3>Login</h3>
      <?php
      if(isset($error) && is_array($error)) { // Check if $error is an array
         foreach($error as $errorMsg) { // Use a different variable name to avoid conflict
            echo '<span class="error-msg">'.$errorMsg.'</span>';
         }
      }
      ?>
      <input type="email" name="email" required placeholder="Enter your email">
      <input type="password" name="password" required placeholder="Enter your password">
      <input type="submit" name="login" value="Login" class="form-btn">
      <p>Don't have an account? <a href="register_form.php">Register now</a></p>
   </form>
</div>
</body>
</html>
