<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>user page</title>
   <link rel="stylesheet" href="../index.css">
   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
<nav id="navbar">
        <ul>
            <div id="home_logo">
                <a href="index.html"><img src="home_logo.png" alt=""></a>
            </div>
            <li class="item"><a href="movies(mysuru).html">Movies</a></li>
            <li class="item"><a href="/events">Events</a></li>
            <li class="item"><a href="/plays">Plays</a></li>
            <li class="item"><a href="/sports">Sports</a></li>
            <li class="item"><a href="/contact">Contact</a></li>
            <li class="item" id="joinus"><a href="/joinus">Join Us</a></li>
        </ul>
</nav>   
<div class="container">

   <div class="content">
      <h3>hi, <span>user</span></h3>
      <h1>welcome <span><?php echo $_SESSION['user_name'] ?></span></h1>
      <p>this is an user page</p>
      <a href="login_form.php" class="btn">login</a>
      <a href="register_form.php" class="btn">register</a>
      <a href="logout.php" class="btn">logout</a>
   </div>

</div>

</body>
</html>